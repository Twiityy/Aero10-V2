Perform a clean installation of StartIsBack ++; and
for cracking, please copy and paste this file in the
SIB++ install folder (StartIsBack).

Enjoy :)
=================

